import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle, FileText, Upload } from 'lucide-react';

export function Dashboard() {
  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-gray-50 to-blue-50/30 min-h-full">
      {/* KPI Cards */}
      <div className="grid grid-cols-5 gap-4">
        <div className="glass-card rounded-xl p-5 hover:shadow-soft-lg transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs text-gray-600">Total Value</span>
            <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-green-600" />
            </div>
          </div>
          <div className="text-2xl text-gray-900 mb-1">Rp 1.2T</div>
          <div className="flex items-center gap-1 text-xs text-green-600">
            <TrendingUp className="w-3 h-3" />
            <span>Active contracts</span>
          </div>
        </div>

        <div className="glass-card rounded-xl p-5 hover:shadow-soft-lg transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs text-gray-600">Total Kontrak</span>
            <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
              <FileText className="w-4 h-4 text-blue-600" />
            </div>
          </div>
          <div className="text-2xl text-gray-900 mb-1">47</div>
          <div className="flex items-center gap-1 text-xs text-green-600">
            <TrendingUp className="w-3 h-3" />
            <span>+3 bulan ini</span>
          </div>
        </div>

        <div className="glass-card rounded-xl p-5 hover:shadow-soft-lg transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs text-gray-600">Total Ruas</span>
            <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-4 h-4 text-purple-600" />
            </div>
          </div>
          <div className="text-2xl text-gray-900 mb-1">1,247</div>
          <div className="text-xs text-gray-500">Nasional</div>
        </div>

        <div className="glass-card rounded-xl p-5 hover:shadow-soft-lg transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs text-gray-600">% Ruas RFS</span>
            <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-yellow-600" />
            </div>
          </div>
          <div className="text-2xl text-gray-900 mb-1">68.5%</div>
          <div className="flex items-center gap-1 text-xs text-green-600">
            <TrendingUp className="w-3 h-3" />
            <span>+5.2% vs target</span>
          </div>
        </div>

        <div className="glass-card rounded-xl p-5 hover:shadow-soft-lg transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs text-gray-600">Evidence Completion</span>
            <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center">
              <Upload className="w-4 h-4 text-orange-600" />
            </div>
          </div>
          <div className="text-2xl text-gray-900 mb-1">82.3%</div>
          <div className="flex items-center gap-1 text-xs text-red-600">
            <TrendingDown className="w-3 h-3" />
            <span>217 ruas pending</span>
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-3 gap-6">
        {/* Progress by Milestone */}
        <div className="col-span-2 glass-card rounded-xl p-6">
          <h3 className="text-sm text-gray-900 mb-4">Progress by Milestone</h3>
          <div className="space-y-3">
            {[
              { name: 'Survey', value: 92, total: 1247, color: 'bg-blue-500' },
              { name: 'DRM', value: 87, total: 1247, color: 'bg-green-500' },
              { name: 'Perizinan', value: 75, total: 1247, color: 'bg-yellow-500' },
              { name: 'Instalasi', value: 68, total: 1247, color: 'bg-orange-500' },
              { name: 'Comtest', value: 52, total: 1247, color: 'bg-purple-500' },
              { name: 'RFS', value: 45, total: 1247, color: 'bg-green-600' },
            ].map(milestone => (
              <div key={milestone.name}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-gray-700">{milestone.name}</span>
                  <span className="text-xs text-gray-500">
                    {Math.round((milestone.value / 100) * milestone.total)} / {milestone.total} ruas
                  </span>
                </div>
                <div className="h-6 bg-gray-100 rounded-lg overflow-hidden shadow-neu-inset">
                  <div 
                    className={`h-full ${milestone.color} flex items-center justify-end px-2 transition-all duration-500`}
                    style={{ width: `${milestone.value}%` }}
                  >
                    <span className="text-xs text-white">{milestone.value}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Risk Panel */}
        <div className="glass-card rounded-xl p-6">
          <h3 className="text-sm text-gray-900 mb-4">Risk Panel</h3>
          <div className="space-y-3">
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
              <div className="flex items-center gap-2 mb-1">
                <AlertTriangle className="w-4 h-4 text-red-600" />
                <span className="text-xs text-red-900">Ruas Terlambat</span>
              </div>
              <div className="text-xl text-red-600">38 ruas</div>
              <div className="text-xs text-red-700 mt-1">{'>'}14 hari dari target</div>
            </div>

            <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-center gap-2 mb-1">
                <AlertTriangle className="w-4 h-4 text-yellow-600" />
                <span className="text-xs text-yellow-900">Tanpa Evidence</span>
              </div>
              <div className="text-xl text-yellow-600">127 ruas</div>
              <div className="text-xs text-yellow-700 mt-1">Belum upload bukti</div>
            </div>

            <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
              <div className="flex items-center gap-2 mb-1">
                <AlertTriangle className="w-4 h-4 text-orange-600" />
                <span className="text-xs text-orange-900">KML Invalid</span>
              </div>
              <div className="text-xl text-orange-600">23 ruas</div>
              <div className="text-xs text-orange-700 mt-1">Format atau koordinat error</div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="glass-card rounded-xl p-6">
        <h3 className="text-sm text-gray-900 mb-4">Aktivitas Terakhir</h3>
        <div className="space-y-3">
          {[
            { type: 'evidence', user: 'Faisal Ahmad', action: 'Upload evidence', target: 'SS-JKT-045 Cell 03', time: '5 menit lalu' },
            { type: 'boq', user: 'Hendra P.', action: 'Update BOQ', target: 'RMJ-2024-001 TREG-2', time: '15 menit lalu' },
            { type: 'milestone', user: 'System', action: 'Milestone changed to RFS', target: 'SS-BDG-012', time: '1 jam lalu' },
            { type: 'evidence', user: 'Subhan R.', action: 'Upload evidence', target: 'SS-SMG-021 SEG-A', time: '2 jam lalu' },
            { type: 'boq', user: 'Ahmad K.', action: 'BOQ Approved', target: 'RMJ-2024-003', time: '3 jam lalu' },
          ].map((activity, idx) => (
            <div key={idx} className="flex items-center gap-4 p-3 hover:bg-white/50 rounded-lg transition-colors border border-transparent hover:border-blue-200">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                activity.type === 'evidence' ? 'bg-green-100' :
                activity.type === 'boq' ? 'bg-blue-100' : 'bg-purple-100'
              }`}>
                {activity.type === 'evidence' && <Upload className="w-5 h-5 text-green-600" />}
                {activity.type === 'boq' && <FileText className="w-5 h-5 text-blue-600" />}
                {activity.type === 'milestone' && <CheckCircle className="w-5 h-5 text-purple-600" />}
              </div>
              <div className="flex-1">
                <div className="text-sm text-gray-900">
                  <span className="font-medium">{activity.user}</span> {activity.action}
                </div>
                <div className="text-xs text-gray-600">{activity.target}</div>
              </div>
              <div className="text-xs text-gray-500">{activity.time}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}