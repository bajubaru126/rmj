import { useState } from 'react';
import { ChevronRight, ChevronDown, FileText, TrendingUp, MapPin, Users, X, Calendar, DollarSign } from 'lucide-react';

interface TreeNode {
  id: string;
  label: string;
  type: 'kontrak' | 'treg' | 'paket' | 'lokasi' | 'ruas';
  children?: TreeNode[];
}

interface KontrakDetail {
  id: string;
  nilai: string;
  ruas: number;
  statusGlobal: string;
  evidencePercent: number;
  startDate: string;
  endDate: string;
  mitra: string;
  pic: string;
  treg: string[];
  paket: string[];
  progressDetail: {
    survey: number;
    drm: number;
    installation: number;
    comtest: number;
    rfs: number;
  };
}

const treeData: TreeNode[] = [
  {
    id: 'k1',
    label: 'RMJ-2024-001',
    type: 'kontrak',
    children: [
      {
        id: 'k1-t1',
        label: 'TREG-1',
        type: 'treg',
        children: [
          {
            id: 'k1-t1-p1',
            label: 'Paket 1',
            type: 'paket',
            children: [
              {
                id: 'k1-t1-p1-l1',
                label: 'Jakarta Pusat',
                type: 'lokasi',
                children: [
                  { id: 'k1-t1-p1-l1-r1', label: 'SS-JKT-001', type: 'ruas' },
                  { id: 'k1-t1-p1-l1-r2', label: 'SS-JKT-002', type: 'ruas' },
                ],
              },
            ],
          },
          {
            id: 'k1-t1-p2',
            label: 'Paket 2',
            type: 'paket',
          },
        ],
      },
      {
        id: 'k1-t2',
        label: 'TREG-2',
        type: 'treg',
      },
    ],
  },
  {
    id: 'k2',
    label: 'RMJ-2024-002',
    type: 'kontrak',
    children: [
      {
        id: 'k2-t1',
        label: 'TREG-3',
        type: 'treg',
      },
    ],
  },
];

const kontrakData: KontrakDetail[] = [
  {
    id: 'RMJ-2024-001',
    nilai: 'Rp 450,000,000',
    ruas: 127,
    statusGlobal: 'On Progress',
    evidencePercent: 82,
    startDate: '2024-01-15',
    endDate: '2024-12-31',
    mitra: 'PT Meindo Elang',
    pic: 'Faisal Ahmad',
    treg: ['TREG-1', 'TREG-2'],
    paket: ['Paket 1', 'Paket 2', 'Paket 3'],
    progressDetail: {
      survey: 95,
      drm: 87,
      installation: 65,
      comtest: 45,
      rfs: 38,
    },
  },
  {
    id: 'RMJ-2024-002',
    nilai: 'Rp 320,000,000',
    ruas: 89,
    statusGlobal: 'On Progress',
    evidencePercent: 75,
    startDate: '2024-02-01',
    endDate: '2024-11-30',
    mitra: 'PT Sumatera Network',
    pic: 'Hendra Pratama',
    treg: ['TREG-3', 'TREG-4'],
    paket: ['Paket 1', 'Paket 2'],
    progressDetail: {
      survey: 88,
      drm: 72,
      installation: 58,
      comtest: 42,
      rfs: 35,
    },
  },
  {
    id: 'RMJ-2023-045',
    nilai: 'Rp 280,000,000',
    ruas: 64,
    statusGlobal: 'Done',
    evidencePercent: 100,
    startDate: '2023-06-01',
    endDate: '2024-03-31',
    mitra: 'PT Telkom Infra',
    pic: 'Subhan Rahman',
    treg: ['TREG-5'],
    paket: ['Paket 1'],
    progressDetail: {
      survey: 100,
      drm: 100,
      installation: 100,
      comtest: 100,
      rfs: 100,
    },
  },
];

export function KontrakExplorer() {
  const [expanded, setExpanded] = useState<Set<string>>(new Set(['k1', 'k1-t1']));
  const [selected, setSelected] = useState<string>('k1');
  const [selectedKontrak, setSelectedKontrak] = useState<KontrakDetail | null>(null);

  const toggleNode = (nodeId: string) => {
    const newExpanded = new Set(expanded);
    if (newExpanded.has(nodeId)) {
      newExpanded.delete(nodeId);
    } else {
      newExpanded.add(nodeId);
    }
    setExpanded(newExpanded);
  };

  const handleViewDetails = (kontrakId: string) => {
    const kontrak = kontrakData.find(k => k.id === kontrakId);
    if (kontrak) {
      setSelectedKontrak(kontrak);
    }
  };

  const renderTree = (nodes: TreeNode[], depth: number = 0): JSX.Element[] => {
    return nodes.map(node => {
      const isExpanded = expanded.has(node.id);
      const hasChildren = node.children && node.children.length > 0;
      const isSelected = selected === node.id;

      return (
        <div key={node.id}>
          <div
            className={`flex items-center gap-2 px-3 py-2 cursor-pointer transition-colors rounded ${
              isSelected ? 'bg-blue-100 text-blue-900' : 'hover:bg-gray-100 text-gray-700'
            }`}
            style={{ paddingLeft: `${depth * 20 + 12}px` }}
            onClick={() => setSelected(node.id)}
          >
            {hasChildren && (
              <button onClick={(e) => { e.stopPropagation(); toggleNode(node.id); }} className="hover:bg-gray-200 rounded p-0.5">
                {isExpanded ? (
                  <ChevronDown className="w-4 h-4" />
                ) : (
                  <ChevronRight className="w-4 h-4" />
                )}
              </button>
            )}
            {!hasChildren && <div className="w-4" />}
            <span className="text-sm">{node.label}</span>
          </div>
          {isExpanded && hasChildren && (
            <div>{renderTree(node.children!, depth + 1)}</div>
          )}
        </div>
      );
    });
  };

  return (
    <div className="flex h-full bg-gradient-to-br from-gray-50 to-blue-50/30">
      {/* Sidebar - Hierarchy Tree */}
      <div className="w-80 bg-white border-r border-gray-200 flex flex-col shadow-soft">
        <div className="p-4 border-b border-gray-200 bg-[#F8F8F8]">
          <h3 className="text-sm text-gray-900">RMJ Hierarchy</h3>
          <p className="text-xs text-gray-500 mt-1">Kontrak → TREG → Paket → Lokasi → Ruas</p>
        </div>

        <div className="flex-1 overflow-auto p-2">
          {renderTree(treeData)}
        </div>
      </div>

      {/* Main Panel - Kontrak Cards */}
      <div className="flex-1 overflow-auto p-6">
        <div className="mb-6">
          <h2 className="text-xl text-gray-900 mb-1">Kontrak Explorer</h2>
          <p className="text-sm text-gray-600">Manage and monitor all RMJ contracts</p>
        </div>

        <div className="grid grid-cols-3 gap-6">
          {kontrakData.map(kontrak => (
            <div key={kontrak.id} className="glass-card rounded-xl p-6 hover:shadow-soft-lg transition-all">
              {/* Header */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <FileText className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-sm text-gray-900">{kontrak.id}</h3>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      kontrak.statusGlobal === 'Done' 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-yellow-100 text-yellow-700'
                    }`}>
                      {kontrak.statusGlobal}
                    </span>
                  </div>
                </div>
              </div>

              {/* Stats */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-600">Nilai Kontrak</span>
                  <span className="text-sm text-gray-900">{kontrak.nilai}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-600">Jumlah Ruas</span>
                  <div className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-gray-500" />
                    <span className="text-sm text-gray-900">{kontrak.ruas} ruas</span>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-gray-600">Evidence Completion</span>
                    <span className="text-xs text-gray-700">{kontrak.evidencePercent}%</span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${
                        kontrak.evidencePercent === 100 ? 'bg-green-500' : 
                        kontrak.evidencePercent >= 80 ? 'bg-blue-500' : 'bg-yellow-500'
                      }`}
                      style={{ width: `${kontrak.evidencePercent}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="mt-4 pt-4 border-t border-gray-200 flex gap-2">
                <button 
                  onClick={() => handleViewDetails(kontrak.id)}
                  className="flex-1 px-3 py-2 bg-white border border-gray-300 rounded text-xs hover:bg-gray-50"
                >
                  View Details
                </button>
                <button className="flex-1 px-3 py-2 bg-[#005EB8] text-white rounded text-xs hover:bg-[#004a94]">
                  Manage
                </button>
              </div>
            </div>
          ))}

          {/* Add New Kontrak Card */}
          <div className="glass-card-dark rounded-xl p-6 border-2 border-dashed border-gray-300 flex items-center justify-center hover:border-blue-400 hover:bg-blue-50/10 transition-all cursor-pointer">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                <FileText className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-sm text-gray-900 mb-1">Add New Kontrak</h3>
              <p className="text-xs text-gray-600">Create a new RMJ contract</p>
            </div>
          </div>
        </div>

        {/* Summary Stats */}
        <div className="mt-8 grid grid-cols-4 gap-4">
          <div className="glass-card rounded-lg p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <FileText className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <div className="text-xs text-gray-600">Active Contracts</div>
                <div className="text-xl text-gray-900">47</div>
              </div>
            </div>
          </div>

          <div className="glass-card rounded-lg p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <div className="text-xs text-gray-600">Total Value</div>
                <div className="text-xl text-gray-900">Rp 1.2T</div>
              </div>
            </div>
          </div>

          <div className="glass-card rounded-lg p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <MapPin className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <div className="text-xs text-gray-600">Total Ruas</div>
                <div className="text-xl text-gray-900">1,247</div>
              </div>
            </div>
          </div>

          <div className="glass-card rounded-lg p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <Users className="w-5 h-5 text-orange-600" />
              </div>
              <div>
                <div className="text-xs text-gray-600">Active Vendors</div>
                <div className="text-xl text-gray-900">23</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Contract Detail Modal */}
      {selectedKontrak && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-6">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
            {/* Header */}
            <div className="p-6 border-b border-gray-200 bg-gradient-to-r from-[#003A70] to-[#005EB8] flex items-center justify-between">
              <div>
                <h3 className="text-white text-lg">{selectedKontrak.id}</h3>
                <p className="text-xs text-blue-100 mt-1">Contract Details & Progress</p>
              </div>
              <button 
                onClick={() => setSelectedKontrak(null)} 
                className="p-2 hover:bg-white/10 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-white" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-auto p-6">
              {/* Overview Cards */}
              <div className="grid grid-cols-4 gap-4 mb-6">
                <div className="glass-card rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <DollarSign className="w-4 h-4 text-green-600" />
                    <span className="text-xs text-gray-600">Nilai Kontrak</span>
                  </div>
                  <div className="text-lg text-gray-900">{selectedKontrak.nilai}</div>
                </div>

                <div className="glass-card rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <MapPin className="w-4 h-4 text-blue-600" />
                    <span className="text-xs text-gray-600">Total Ruas</span>
                  </div>
                  <div className="text-lg text-gray-900">{selectedKontrak.ruas} ruas</div>
                </div>

                <div className="glass-card rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="w-4 h-4 text-purple-600" />
                    <span className="text-xs text-gray-600">Periode</span>
                  </div>
                  <div className="text-xs text-gray-900">
                    {selectedKontrak.startDate} s/d {selectedKontrak.endDate}
                  </div>
                </div>

                <div className="glass-card rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Users className="w-4 h-4 text-orange-600" />
                    <span className="text-xs text-gray-600">MITRA</span>
                  </div>
                  <div className="text-xs text-gray-900">{selectedKontrak.mitra}</div>
                </div>
              </div>

              {/* Contract Information */}
              <div className="glass-card rounded-lg p-6 mb-6">
                <h4 className="text-sm text-gray-900 mb-4">Contract Information</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <span className="text-xs text-gray-600">PIC</span>
                    <div className="text-sm text-gray-900 mt-1">{selectedKontrak.pic}</div>
                  </div>
                  <div>
                    <span className="text-xs text-gray-600">Status</span>
                    <div className="mt-1">
                      <span className={`text-xs px-3 py-1 rounded-full ${
                        selectedKontrak.statusGlobal === 'Done' 
                          ? 'bg-green-100 text-green-700' 
                          : 'bg-yellow-100 text-yellow-700'
                      }`}>
                        {selectedKontrak.statusGlobal}
                      </span>
                    </div>
                  </div>
                  <div>
                    <span className="text-xs text-gray-600">TREG Coverage</span>
                    <div className="text-sm text-gray-900 mt-1">{selectedKontrak.treg.join(', ')}</div>
                  </div>
                  <div>
                    <span className="text-xs text-gray-600">Paket Area</span>
                    <div className="text-sm text-gray-900 mt-1">{selectedKontrak.paket.join(', ')}</div>
                  </div>
                </div>
              </div>

              {/* Progress Detail */}
              <div className="glass-card rounded-lg p-6">
                <h4 className="text-sm text-gray-900 mb-4">Progress Detail by Milestone</h4>
                <div className="space-y-3">
                  {[
                    { name: 'Survey', value: selectedKontrak.progressDetail.survey, color: 'bg-blue-500' },
                    { name: 'DRM', value: selectedKontrak.progressDetail.drm, color: 'bg-green-500' },
                    { name: 'Installation', value: selectedKontrak.progressDetail.installation, color: 'bg-orange-500' },
                    { name: 'Comtest', value: selectedKontrak.progressDetail.comtest, color: 'bg-purple-500' },
                    { name: 'RFS', value: selectedKontrak.progressDetail.rfs, color: 'bg-green-600' },
                  ].map(milestone => (
                    <div key={milestone.name}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs text-gray-700">{milestone.name}</span>
                        <span className="text-xs text-gray-500">
                          {Math.round((milestone.value / 100) * selectedKontrak.ruas)} / {selectedKontrak.ruas} ruas ({milestone.value}%)
                        </span>
                      </div>
                      <div className="h-6 bg-gray-100 rounded-lg overflow-hidden shadow-neu-inset">
                        <div 
                          className={`h-full ${milestone.color} flex items-center justify-end px-2 transition-all duration-500`}
                          style={{ width: `${milestone.value}%` }}
                        >
                          <span className="text-xs text-white">{milestone.value}%</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Evidence Status */}
              <div className="glass-card rounded-lg p-6 mt-6">
                <h4 className="text-sm text-gray-900 mb-4">Evidence Completion</h4>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <div className="h-8 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className={`h-full flex items-center justify-end px-3 ${
                          selectedKontrak.evidencePercent === 100 ? 'bg-green-500' : 
                          selectedKontrak.evidencePercent >= 80 ? 'bg-blue-500' : 'bg-yellow-500'
                        }`}
                        style={{ width: `${selectedKontrak.evidencePercent}%` }}
                      >
                        <span className="text-sm text-white">{selectedKontrak.evidencePercent}%</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-gray-900">{Math.round((selectedKontrak.evidencePercent / 100) * selectedKontrak.ruas)} / {selectedKontrak.ruas}</div>
                    <div className="text-xs text-gray-500">Ruas completed</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-6 border-t border-gray-200 bg-gray-50 flex justify-end gap-3">
              <button 
                onClick={() => setSelectedKontrak(null)}
                className="px-4 py-2 border border-gray-300 rounded text-sm hover:bg-gray-100"
              >
                Close
              </button>
              <button className="px-4 py-2 bg-[#005EB8] text-white rounded text-sm hover:bg-[#004a94]">
                Manage Contract
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}