import { useState } from 'react';
import { ChevronRight, ChevronDown, Paperclip, MapPin, Eye, Edit, Trash2, Upload, CheckCircle, AlertCircle, Image as ImageIcon } from 'lucide-react';

interface CellData {
  id: string;
  cellName: string;
  length: string;
  material: string;
  owner: string;
  status: 'OK' | 'Delay' | 'Issue';
  evidenceCount: number;
  hasKML: boolean;
  evidencePhotos?: string[];
}

interface SegmentasiData {
  id: string;
  segName: string;
  length: string;
  status: string;
  cells: CellData[];
}

interface RuasData {
  id: string;
  tahunProject: string;
  program: string;
  projectSitelist: string;
  siteName: string;
  regional: string;
  project: string;
  mitra: string;
  planRFS: string;
  spCurrMilestone: string;
  m0sInstallation: boolean;
  planEndDate: string;
  actualEndDate?: string;
  owner: string;
  segmentasi?: SegmentasiData[];
}

const mockRuasData: RuasData[] = [
  {
    id: 'r1',
    tahunProject: '2024',
    program: 'RMJ Ring Jawbel',
    projectSitelist: 'UNX-JKT-001',
    siteName: 'K BARUSUJIAN',
    regional: 'R01 Sumbasel',
    project: 'PRJ-001',
    mitra: 'PT Meindo',
    planRFS: '2024-06-30',
    spCurrMilestone: 'Implementation',
    m0sInstallation: true,
    planEndDate: '2024-06-15',
    actualEndDate: '2024-06-10',
    owner: 'Faisal Ahmad',
    segmentasi: [
      {
        id: 'seg1',
        segName: 'SEG-A',
        length: '2.5 km',
        status: 'Progress',
        cells: [
          {
            id: 'cell1',
            cellName: 'CELL-01',
            length: '500m',
            material: 'FO 48 Core',
            owner: 'Team A',
            status: 'OK',
            evidenceCount: 5,
            hasKML: true,
            evidencePhotos: ['photo1', 'photo2'],
          },
          {
            id: 'cell2',
            cellName: 'CELL-02',
            length: '500m',
            material: 'FO 48 Core',
            owner: 'Team A',
            status: 'OK',
            evidenceCount: 4,
            hasKML: true,
          },
          {
            id: 'cell3',
            cellName: 'CELL-03',
            length: '500m',
            material: 'FO 48 Core',
            owner: 'Team B',
            status: 'Delay',
            evidenceCount: 2,
            hasKML: true,
          },
          {
            id: 'cell4',
            cellName: 'CELL-04',
            length: '500m',
            material: 'FO 48 Core',
            owner: 'Team A',
            status: 'OK',
            evidenceCount: 6,
            hasKML: true,
          },
          {
            id: 'cell5',
            cellName: 'CELL-05',
            length: '500m',
            material: 'FO 48 Core',
            owner: 'Team B',
            status: 'OK',
            evidenceCount: 5,
            hasKML: true,
          },
        ],
      },
      {
        id: 'seg2',
        segName: 'SEG-B',
        length: '1.8 km',
        status: 'OK',
        cells: [
          {
            id: 'cell6',
            cellName: 'CELL-06',
            length: '600m',
            material: 'FO 96 Core',
            owner: 'Team C',
            status: 'OK',
            evidenceCount: 7,
            hasKML: true,
          },
          {
            id: 'cell7',
            cellName: 'CELL-07',
            length: '600m',
            material: 'FO 96 Core',
            owner: 'Team C',
            status: 'Issue',
            evidenceCount: 1,
            hasKML: false,
          },
          {
            id: 'cell8',
            cellName: 'CELL-08',
            length: '600m',
            material: 'FO 96 Core',
            owner: 'Team C',
            status: 'OK',
            evidenceCount: 8,
            hasKML: true,
          },
        ],
      },
    ],
  },
  {
    id: 'r2',
    tahunProject: '2024',
    program: 'RMJ Metro',
    projectSitelist: 'UNX-BDG-045',
    siteName: 'BANDUNG CENTRAL',
    regional: 'R02 Jawa Barat',
    project: 'PRJ-002',
    mitra: 'PT Sumatera',
    planRFS: '2024-07-15',
    spCurrMilestone: 'Survey',
    m0sInstallation: false,
    planEndDate: '2024-07-01',
    owner: 'Hendra Pratama',
  },
];

export function RuasDRM() {
  const [selectedRows, setSelectedRows] = useState<string[]>([]);
  const [expandedRuas, setExpandedRuas] = useState<Set<string>>(new Set(['r1']));
  const [expandedSegmentasi, setExpandedSegmentasi] = useState<Set<string>>(new Set(['seg1']));
  const [activeTab, setActiveTab] = useState<{ [key: string]: string }>({ r1: 'segmentasi' });
  const [selectedCell, setSelectedCell] = useState<CellData | null>(null);

  const toggleRuas = (ruasId: string) => {
    const newExpanded = new Set(expandedRuas);
    if (newExpanded.has(ruasId)) {
      newExpanded.delete(ruasId);
    } else {
      newExpanded.add(ruasId);
      if (!activeTab[ruasId]) {
        setActiveTab({ ...activeTab, [ruasId]: 'drm' });
      }
    }
    setExpandedRuas(newExpanded);
  };

  const toggleSegmentasi = (segId: string) => {
    const newExpanded = new Set(expandedSegmentasi);
    if (newExpanded.has(segId)) {
      newExpanded.delete(segId);
    } else {
      newExpanded.add(segId);
    }
    setExpandedSegmentasi(newExpanded);
  };

  const handleSelectRow = (rowId: string) => {
    setSelectedRows(prev =>
      prev.includes(rowId) ? prev.filter(id => id !== rowId) : [...prev, rowId]
    );
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'OK': return 'bg-[#4CAF50] text-white';
      case 'Delay': return 'bg-[#FFC107] text-gray-900';
      case 'Issue': return 'bg-[#FF5252] text-white';
      case 'Implementation': return 'bg-blue-500 text-white';
      case 'Survey': return 'bg-purple-500 text-white';
      default: return 'bg-gray-200 text-gray-700';
    }
  };

  return (
    <div className="flex h-full bg-gradient-to-br from-gray-50 to-blue-50/30">
      {/* Main Table */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <div className="bg-white border-b border-gray-200 p-4">
          <div className="flex items-center gap-3">
            <input
              type="text"
              placeholder="Search Ruas..."
              className="px-4 py-2 border border-gray-300 rounded w-64"
            />
            <select className="px-3 py-2 border border-gray-300 rounded">
              <option>TREG</option>
              <option>TREG-1</option>
              <option>TREG-2</option>
            </select>
            <select className="px-3 py-2 border border-gray-300 rounded">
              <option>Milestone</option>
              <option>Survey</option>
              <option>Implementation</option>
            </select>
            <select className="px-3 py-2 border border-gray-300 rounded">
              <option>MITRA</option>
              <option>PT Meindo</option>
              <option>PT Sumatera</option>
            </select>

            <div className="flex-1"></div>

            <button className="px-4 py-2 bg-white border border-gray-300 rounded text-sm hover:bg-gray-50">
              + Tambah Ruas
            </button>
            <button className="px-4 py-2 bg-white border border-gray-300 rounded text-sm hover:bg-gray-50">
              Upload DRM
            </button>
            <button className="px-4 py-2 bg-[#005EB8] text-white rounded text-sm hover:bg-[#004a94]">
              Import KML
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="flex-1 overflow-auto p-6">
          <div className="glass-card rounded-xl overflow-hidden">
            <table className="w-full">
              <thead className="glass-table-header sticky top-0">
                <tr>
                  <th className="px-3 py-3 w-12">
                    <input type="checkbox" className="rounded" />
                  </th>
                  <th className="px-3 py-3 text-left text-xs text-gray-700 min-w-[80px]">Tahun Project</th>
                  <th className="px-3 py-3 text-left text-xs text-gray-700 min-w-[150px]">Program</th>
                  <th className="px-3 py-3 text-left text-xs text-gray-700 min-w-[130px]">PROJECT_SITELIST / UNXID</th>
                  <th className="px-3 py-3 text-left text-xs text-gray-700 min-w-[150px]">Site Name</th>
                  <th className="px-3 py-3 text-left text-xs text-gray-700 min-w-[120px]">Regional</th>
                  <th className="px-3 py-3 text-left text-xs text-gray-700 min-w-[100px]">Project</th>
                  <th className="px-3 py-3 text-left text-xs text-gray-700 min-w-[120px]">MITRA</th>
                  <th className="px-3 py-3 text-left text-xs text-gray-700 min-w-[100px]">PLAN RFS</th>
                  <th className="px-3 py-3 text-left text-xs text-gray-700 min-w-[130px]">S.P Curr. Milestone</th>
                  <th className="px-3 py-3 text-center text-xs text-gray-700 min-w-[120px]">M-0S Installation Completed</th>
                  <th className="px-3 py-3 text-left text-xs text-gray-700 min-w-[110px]">Plan End Date</th>
                  <th className="px-3 py-3 text-left text-xs text-gray-700 min-w-[110px]">Actual End Date</th>
                  <th className="px-3 py-3 text-left text-xs text-gray-700 min-w-[120px]">Owner</th>
                  <th className="px-3 py-3 text-center text-xs text-gray-700 w-32">Action</th>
                </tr>
              </thead>
              <tbody className="bg-white">
                {mockRuasData.map((ruas, idx) => {
                  const isExpanded = expandedRuas.has(ruas.id);
                  const currentTab = activeTab[ruas.id] || 'drm';

                  return (
                    <>
                      {/* Main Row */}
                      <tr
                        key={ruas.id}
                        className={`border-b border-gray-200 hover:bg-blue-50/30 transition-colors ${
                          idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'
                        }`}
                      >
                        <td className="px-3 py-3">
                          <input
                            type="checkbox"
                            checked={selectedRows.includes(ruas.id)}
                            onChange={() => handleSelectRow(ruas.id)}
                            className="rounded"
                          />
                        </td>
                        <td className="px-3 py-3 text-sm">{ruas.tahunProject}</td>
                        <td className="px-3 py-3">
                          <div className="flex items-center gap-2">
                            <button onClick={() => toggleRuas(ruas.id)} className="hover:bg-gray-200 rounded p-0.5">
                              {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                            </button>
                            <span className="text-sm">{ruas.program}</span>
                          </div>
                        </td>
                        <td className="px-3 py-3 text-sm">{ruas.projectSitelist}</td>
                        <td className="px-3 py-3 text-sm">{ruas.siteName}</td>
                        <td className="px-3 py-3 text-sm">{ruas.regional}</td>
                        <td className="px-3 py-3 text-sm">{ruas.project}</td>
                        <td className="px-3 py-3 text-sm">{ruas.mitra}</td>
                        <td className="px-3 py-3 text-sm">{ruas.planRFS}</td>
                        <td className="px-3 py-3">
                          <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(ruas.spCurrMilestone)}`}>
                            {ruas.spCurrMilestone}
                          </span>
                        </td>
                        <td className="px-3 py-3 text-center">
                          {ruas.m0sInstallation ? (
                            <CheckCircle className="w-5 h-5 text-green-600 inline-block" />
                          ) : (
                            <span className="text-xs text-gray-400">-</span>
                          )}
                        </td>
                        <td className="px-3 py-3 text-sm">{ruas.planEndDate}</td>
                        <td className="px-3 py-3 text-sm">{ruas.actualEndDate || '-'}</td>
                        <td className="px-3 py-3 text-sm">{ruas.owner}</td>
                        <td className="px-3 py-3">
                          <div className="flex items-center justify-center gap-1">
                            <button className="p-1 hover:bg-gray-200 rounded" title="View">
                              <Eye className="w-4 h-4 text-gray-600" />
                            </button>
                            <button className="p-1 hover:bg-gray-200 rounded" title="Edit">
                              <Edit className="w-4 h-4 text-blue-600" />
                            </button>
                            <button className="p-1 hover:bg-gray-200 rounded" title="Delete">
                              <Trash2 className="w-4 h-4 text-red-600" />
                            </button>
                          </div>
                        </td>
                      </tr>

                      {/* Expanded Row - Tabs */}
                      {isExpanded && (
                        <tr>
                          <td colSpan={15} className="p-0 bg-gray-50/80">
                            {/* Tab Headers */}
                            <div className="flex border-b border-gray-200 px-6 bg-white/60">
                              {['drm', 'boq', 'iboq', 'segmentasi', 'issue', 'evidence', 'kml'].map(tab => (
                                <button
                                  key={tab}
                                  onClick={() => setActiveTab({ ...activeTab, [ruas.id]: tab })}
                                  className={`px-4 py-2 text-xs border-b-2 transition-colors ${
                                    currentTab === tab
                                      ? 'border-[#005EB8] text-[#005EB8]'
                                      : 'border-transparent text-gray-600 hover:text-gray-900'
                                  }`}
                                >
                                  {tab === 'drm' && 'DRM Data'}
                                  {tab === 'boq' && 'BOQ Customer'}
                                  {tab === 'iboq' && 'Indikatif BOQ'}
                                  {tab === 'segmentasi' && 'Segmentasi & Cell'}
                                  {tab === 'issue' && 'Issue Log'}
                                  {tab === 'evidence' && 'Evidence'}
                                  {tab === 'kml' && 'KML Map'}
                                </button>
                              ))}
                            </div>

                            {/* Tab Content */}
                            <div className="p-6 nested-row-bg">
                              {currentTab === 'segmentasi' && ruas.segmentasi && (
                                <div className="space-y-3">
                                  {ruas.segmentasi.map(seg => {
                                    const isSegExpanded = expandedSegmentasi.has(seg.id);
                                    return (
                                      <div key={seg.id} className="glass-card rounded-lg overflow-hidden">
                                        {/* Segmentasi Header */}
                                        <div
                                          className="flex items-center justify-between p-4 cursor-pointer hover:bg-blue-50/30 transition-colors"
                                          onClick={() => toggleSegmentasi(seg.id)}
                                        >
                                          <div className="flex items-center gap-3">
                                            <button className="hover:bg-gray-200 rounded p-1">
                                              {isSegExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                                            </button>
                                            <div>
                                              <span className="text-sm text-gray-900">{seg.segName}</span>
                                              <span className="text-xs text-gray-500 ml-2">({seg.length})</span>
                                            </div>
                                          </div>
                                          <span className={`px-3 py-1 rounded-full text-xs ${
                                            seg.status === 'OK' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                                          }`}>
                                            {seg.status}
                                          </span>
                                        </div>

                                        {/* Cell Table */}
                                        {isSegExpanded && (
                                          <div className="border-t border-gray-200">
                                            <table className="w-full">
                                              <thead className="bg-gray-100/80">
                                                <tr>
                                                  <th className="px-4 py-2 text-left text-xs text-gray-700">Cell</th>
                                                  <th className="px-4 py-2 text-left text-xs text-gray-700">Length</th>
                                                  <th className="px-4 py-2 text-left text-xs text-gray-700">Material</th>
                                                  <th className="px-4 py-2 text-left text-xs text-gray-700">Owner</th>
                                                  <th className="px-4 py-2 text-center text-xs text-gray-700">Status</th>
                                                  <th className="px-4 py-2 text-center text-xs text-gray-700">Evidence</th>
                                                  <th className="px-4 py-2 text-center text-xs text-gray-700">KML</th>
                                                  <th className="px-4 py-2 text-center text-xs text-gray-700">Action</th>
                                                </tr>
                                              </thead>
                                              <tbody className="bg-white">
                                                {seg.cells.map((cell, cellIdx) => (
                                                  <tr
                                                    key={cell.id}
                                                    onClick={() => setSelectedCell(cell)}
                                                    className={`border-b border-gray-100 hover:bg-blue-50/50 cursor-pointer transition-colors ${
                                                      cellIdx % 2 === 0 ? 'bg-white' : 'bg-gray-50/30'
                                                    }`}
                                                  >
                                                    <td className="px-4 py-2 text-sm">{cell.cellName}</td>
                                                    <td className="px-4 py-2 text-sm">{cell.length}</td>
                                                    <td className="px-4 py-2 text-sm">{cell.material}</td>
                                                    <td className="px-4 py-2 text-sm">{cell.owner}</td>
                                                    <td className="px-4 py-2 text-center">
                                                      <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(cell.status)}`}>
                                                        {cell.status}
                                                      </span>
                                                    </td>
                                                    <td className="px-4 py-2 text-center">
                                                      <button className="flex items-center gap-1 text-xs text-blue-600 hover:underline mx-auto">
                                                        <Paperclip className="w-3 h-3" />
                                                        {cell.evidenceCount} files
                                                      </button>
                                                    </td>
                                                    <td className="px-4 py-2 text-center">
                                                      {cell.hasKML ? (
                                                        <button className="text-xs text-green-600 hover:underline">View KML</button>
                                                      ) : (
                                                        <span className="text-xs text-red-600">No KML</span>
                                                      )}
                                                    </td>
                                                    <td className="px-4 py-2">
                                                      <div className="flex items-center justify-center gap-1">
                                                        <button className="p-1 hover:bg-gray-200 rounded" title="View">
                                                          <Eye className="w-3 h-3 text-gray-600" />
                                                        </button>
                                                        <button className="p-1 hover:bg-gray-200 rounded" title="Upload Evidence">
                                                          <Upload className="w-3 h-3 text-blue-600" />
                                                        </button>
                                                        <button className="p-1 hover:bg-gray-200 rounded" title="Map">
                                                          <MapPin className="w-3 h-3 text-green-600" />
                                                        </button>
                                                      </div>
                                                    </td>
                                                  </tr>
                                                ))}
                                              </tbody>
                                            </table>
                                          </div>
                                        )}
                                      </div>
                                    );
                                  })}
                                </div>
                              )}

                              {currentTab === 'drm' && (
                                <div className="text-sm text-gray-600">DRM Data content...</div>
                              )}

                              {currentTab === 'evidence' && (
                                <div className="text-sm text-gray-600">Evidence content...</div>
                              )}

                              {currentTab === 'kml' && (
                                <div className="h-64 bg-gray-200 rounded flex items-center justify-center">
                                  <MapPin className="w-12 h-12 text-gray-400" />
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      )}
                    </>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Right Panel - Cell Evidence Detail */}
      {selectedCell && (
        <div className="w-96 bg-white border-l border-gray-200 shadow-soft-lg flex flex-col">
          <div className="p-4 border-b border-gray-200 bg-gradient-to-r from-[#003A70] to-[#005EB8]">
            <h3 className="text-white text-sm">Cell Evidence</h3>
            <p className="text-xs text-blue-100 mt-1">{selectedCell.cellName}</p>
          </div>

          <div className="flex-1 overflow-auto p-4">
            <div className="space-y-4">
              {/* Cell Info */}
              <div className="glass-card rounded-lg p-4">
                <h4 className="text-xs text-gray-600 mb-3">Cell Information</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Length:</span>
                    <span className="text-gray-900">{selectedCell.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Material:</span>
                    <span className="text-gray-900">{selectedCell.material}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Owner:</span>
                    <span className="text-gray-900">{selectedCell.owner}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Status:</span>
                    <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(selectedCell.status)}`}>
                      {selectedCell.status}
                    </span>
                  </div>
                </div>
              </div>

              {/* Evidence Photos */}
              <div className="glass-card rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs text-gray-600">Evidence Photos ({selectedCell.evidenceCount})</h4>
                  <button className="text-xs text-blue-600 hover:underline">Upload</button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {[1, 2, 3, 4].map(i => (
                    <div key={i} className="aspect-square bg-gray-100 rounded flex items-center justify-center">
                      <ImageIcon className="w-8 h-8 text-gray-400" />
                    </div>
                  ))}
                </div>
              </div>

              {/* KML Preview */}
              <div className="glass-card rounded-lg p-4">
                <h4 className="text-xs text-gray-600 mb-3">KML Location</h4>
                <div className="h-32 bg-gray-200 rounded flex items-center justify-center mb-3">
                  <MapPin className="w-8 h-8 text-gray-400" />
                </div>
                <button className="w-full px-3 py-2 bg-[#005EB8] text-white rounded text-xs hover:bg-[#004a94]">
                  Open in Map
                </button>
              </div>

              {/* Evidence Files */}
              <div className="glass-card rounded-lg p-4">
                <h4 className="text-xs text-gray-600 mb-3">Evidence Files</h4>
                <div className="space-y-2">
                  {['survey_report.pdf', 'installation_photo.jpg', 'test_result.xlsx'].map((file, idx) => (
                    <div key={idx} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                      <Paperclip className="w-4 h-4 text-gray-600" />
                      <div className="flex-1">
                        <div className="text-xs text-gray-900">{file}</div>
                        <div className="text-xs text-gray-500">2024-03-15 14:30</div>
                      </div>
                      <button className="p-1 hover:bg-gray-200 rounded">
                        <Eye className="w-3 h-3 text-blue-600" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
