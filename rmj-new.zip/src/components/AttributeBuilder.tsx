import { X, Save, Plus, Trash2 } from 'lucide-react';
import { useState } from 'react';

interface AttributeBuilderProps {
  onClose: () => void;
}

export function AttributeBuilder({ onClose }: AttributeBuilderProps) {
  const [attributeName, setAttributeName] = useState('');
  const [attributeType, setAttributeType] = useState('text');
  const [attachedTo, setAttachedTo] = useState<string[]>([]);
  const [accessLevel, setAccessLevel] = useState('modify');

  const handleAttachedToToggle = (value: string) => {
    setAttachedTo(prev =>
      prev.includes(value)
        ? prev.filter(v => v !== value)
        : [...prev, value]
    );
  };

  return (
    <div className="w-96 bg-white border-l border-[#D1D5DB] flex flex-col shadow-lg">
      {/* Header */}
      <div className="p-6 border-b border-[#D1D5DB] flex items-center justify-between bg-gradient-to-r from-[#003A70] to-[#005EB8]">
        <div>
          <h3 className="text-white text-lg">Attribute Builder</h3>
          <p className="text-xs text-blue-100 mt-1">Create custom attributes for RMJ data</p>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-white/10 rounded transition-colors">
          <X className="w-5 h-5 text-white" />
        </button>
      </div>

      {/* Form Content */}
      <div className="flex-1 overflow-y-auto p-6">
        {/* Attribute Name */}
        <div className="mb-6">
          <label className="block text-sm text-gray-700 mb-2">
            Attribute Name <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={attributeName}
            onChange={(e) => setAttributeName(e.target.value)}
            placeholder="e.g., Material Type, Vendor Rating"
            className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Attribute Type */}
        <div className="mb-6">
          <label className="block text-sm text-gray-700 mb-2">
            Attribute Type <span className="text-red-500">*</span>
          </label>
          <select
            value={attributeType}
            onChange={(e) => setAttributeType(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="text">Text</option>
            <option value="number">Number</option>
            <option value="date">Date</option>
            <option value="dropdown">Dropdown</option>
            <option value="multiselect">Multi-Select</option>
            <option value="boolean">Boolean (Yes/No)</option>
          </select>
        </div>

        {/* Attached To */}
        <div className="mb-6">
          <label className="block text-sm text-gray-700 mb-2">
            Attached To <span className="text-red-500">*</span>
          </label>
          <div className="space-y-2">
            {['kontrak', 'ruas', 'boq', 'drm', 'segmentasi', 'cell'].map(item => (
              <label key={item} className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={attachedTo.includes(item)}
                  onChange={() => handleAttachedToToggle(item)}
                  className="rounded"
                />
                <span className="text-sm capitalize">{item}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Default Value */}
        <div className="mb-6">
          <label className="block text-sm text-gray-700 mb-2">
            Default Value
          </label>
          {attributeType === 'text' && (
            <input
              type="text"
              placeholder="Enter default value"
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          )}
          {attributeType === 'number' && (
            <input
              type="number"
              placeholder="0"
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          )}
          {attributeType === 'date' && (
            <input
              type="date"
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          )}
          {attributeType === 'dropdown' && (
            <div className="space-y-2">
              <input
                type="text"
                placeholder="Option 1"
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button className="flex items-center gap-2 text-sm text-blue-600 hover:underline">
                <Plus className="w-4 h-4" />
                Add option
              </button>
            </div>
          )}
          {attributeType === 'boolean' && (
            <select className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="no">No</option>
              <option value="yes">Yes</option>
            </select>
          )}
        </div>

        {/* Access Level */}
        <div className="mb-6">
          <label className="block text-sm text-gray-700 mb-2">
            Access Level
          </label>
          <div className="space-y-2">
            <label className="flex items-center gap-2">
              <input
                type="radio"
                name="access"
                value="view"
                checked={accessLevel === 'view'}
                onChange={(e) => setAccessLevel(e.target.value)}
              />
              <span className="text-sm">View Only</span>
            </label>
            <label className="flex items-center gap-2">
              <input
                type="radio"
                name="access"
                value="modify"
                checked={accessLevel === 'modify'}
                onChange={(e) => setAccessLevel(e.target.value)}
              />
              <span className="text-sm">Modify</span>
            </label>
            <label className="flex items-center gap-2">
              <input
                type="radio"
                name="access"
                value="hidden"
                checked={accessLevel === 'hidden'}
                onChange={(e) => setAccessLevel(e.target.value)}
              />
              <span className="text-sm">Hidden</span>
            </label>
          </div>
        </div>

        {/* Existing Attributes */}
        <div className="mb-6">
          <label className="block text-sm text-gray-700 mb-3">
            Existing Custom Attributes
          </label>
          <div className="space-y-2">
            <div className="flex items-center justify-between p-3 border border-gray-200 rounded bg-gray-50">
              <div>
                <div className="text-sm">Material Quality Rating</div>
                <div className="text-xs text-gray-500">Number • Attached to BOQ</div>
              </div>
              <button className="p-1 hover:bg-gray-200 rounded">
                <Trash2 className="w-4 h-4 text-red-600" />
              </button>
            </div>
            <div className="flex items-center justify-between p-3 border border-gray-200 rounded bg-gray-50">
              <div>
                <div className="text-sm">Vendor Performance</div>
                <div className="text-xs text-gray-500">Dropdown • Attached to Kontrak</div>
              </div>
              <button className="p-1 hover:bg-gray-200 rounded">
                <Trash2 className="w-4 h-4 text-red-600" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Footer Actions */}
      <div className="p-6 border-t border-[#D1D5DB] bg-gray-50">
        <button className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-[#005EB8] text-white rounded hover:bg-[#004a94] transition-colors">
          <Save className="w-4 h-4" />
          Save Attribute
        </button>
        <p className="text-xs text-gray-500 mt-3 text-center">
          New attributes will be added as columns to the table
        </p>
      </div>
    </div>
  );
}
