import { useState } from 'react';
import { Search, Filter, Download, Eye, Edit, Trash2, MapPin, Paperclip } from 'lucide-react';

export function BOQManager() {
  const [selectedBOQ, setSelectedBOQ] = useState<string | null>(null);

  const boqData = [
    {
      id: 'BOQ-001',
      ruas: 'SS-JKT-001',
      kategori: 'A. Kabel',
      uraian: 'Kabel Fiber Optik 48 Core',
      volume: 1500,
      satuan: 'meter',
      hargaSatuan: 125000,
      total: 187500000,
      status: 'Approved',
    },
    {
      id: 'BOQ-002',
      ruas: 'SS-JKT-001',
      kategori: 'B. Manhole',
      uraian: 'Manhole Beton 120x80 cm',
      volume: 25,
      satuan: 'unit',
      hargaSatuan: 3500000,
      total: 87500000,
      status: 'Draft',
    },
    {
      id: 'BOQ-003',
      ruas: 'SS-BDG-002',
      kategori: 'A. Kabel',
      uraian: 'Kabel Fiber Optik 96 Core',
      volume: 2200,
      satuan: 'meter',
      hargaSatuan: 185000,
      total: 407000000,
      status: 'Approved',
    },
  ];

  return (
    <div className="flex h-full bg-gradient-to-br from-gray-50 to-blue-50/30">
      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Filter Bar */}
        <div className="bg-white border-b border-gray-200 p-4">
          <div className="flex items-center gap-3">
            <select className="px-3 py-2 bg-white border border-gray-300 rounded text-sm">
              <option>Tahun Project</option>
              <option>2024</option>
              <option>2023</option>
            </select>

            <select className="px-3 py-2 bg-white border border-gray-300 rounded text-sm">
              <option>Program</option>
              <option>RMJ Ring</option>
              <option>OSP Metro</option>
            </select>

            <select className="px-3 py-2 bg-white border border-gray-300 rounded text-sm">
              <option>MITRA</option>
              <option>PT Meindo</option>
              <option>PT Sumatera</option>
            </select>

            <select className="px-3 py-2 bg-white border border-gray-300 rounded text-sm">
              <option>Status BOQ</option>
              <option>Draft</option>
              <option>Approved</option>
              <option>Rejected</option>
            </select>

            <select className="px-3 py-2 bg-white border border-gray-300 rounded text-sm">
              <option>TREG</option>
              <option>TREG-1</option>
              <option>TREG-2</option>
            </select>

            <div className="flex-1"></div>

            <button className="flex items-center gap-2 px-4 py-2 bg-[#005EB8] text-white rounded hover:bg-[#004a94] text-sm">
              <Download className="w-4 h-4" />
              Export BOQ
            </button>
          </div>
        </div>

        {/* BOQ Table */}
        <div className="flex-1 overflow-auto p-6">
          <div className="glass-card rounded-xl overflow-hidden">
            <table className="w-full">
              <thead className="glass-table-header sticky top-0">
                <tr>
                  <th className="px-4 py-3 text-left text-xs text-gray-700">BOQ ID</th>
                  <th className="px-4 py-3 text-left text-xs text-gray-700">Ruas</th>
                  <th className="px-4 py-3 text-left text-xs text-gray-700">Kategori</th>
                  <th className="px-4 py-3 text-left text-xs text-gray-700">Uraian</th>
                  <th className="px-4 py-3 text-right text-xs text-gray-700">Volume</th>
                  <th className="px-4 py-3 text-left text-xs text-gray-700">Satuan</th>
                  <th className="px-4 py-3 text-right text-xs text-gray-700">Harga Satuan</th>
                  <th className="px-4 py-3 text-right text-xs text-gray-700">Total</th>
                  <th className="px-4 py-3 text-center text-xs text-gray-700">Status</th>
                  <th className="px-4 py-3 text-center text-xs text-gray-700">Action</th>
                </tr>
              </thead>
              <tbody className="bg-white">
                {boqData.map((boq, idx) => (
                  <tr
                    key={boq.id}
                    onClick={() => setSelectedBOQ(boq.id)}
                    className={`border-b border-gray-200 hover:bg-blue-50/50 cursor-pointer transition-colors ${
                      selectedBOQ === boq.id ? 'bg-blue-50' : idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'
                    }`}
                  >
                    <td className="px-4 py-3 text-sm text-blue-600 hover:underline">{boq.id}</td>
                    <td className="px-4 py-3 text-sm">{boq.ruas}</td>
                    <td className="px-4 py-3 text-sm">{boq.kategori}</td>
                    <td className="px-4 py-3 text-sm">{boq.uraian}</td>
                    <td className="px-4 py-3 text-sm text-right">{boq.volume.toLocaleString()}</td>
                    <td className="px-4 py-3 text-sm">{boq.satuan}</td>
                    <td className="px-4 py-3 text-sm text-right">Rp {boq.hargaSatuan.toLocaleString()}</td>
                    <td className="px-4 py-3 text-sm text-right">Rp {boq.total.toLocaleString()}</td>
                    <td className="px-4 py-3 text-center">
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        boq.status === 'Approved' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                      }`}>
                        {boq.status}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        <button className="p-1 hover:bg-gray-200 rounded" title="View">
                          <Eye className="w-4 h-4 text-gray-600" />
                        </button>
                        <button className="p-1 hover:bg-gray-200 rounded" title="Edit">
                          <Edit className="w-4 h-4 text-blue-600" />
                        </button>
                        <button className="p-1 hover:bg-gray-200 rounded" title="Delete">
                          <Trash2 className="w-4 h-4 text-red-600" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Right Panel - BOQ Detail */}
      {selectedBOQ && (
        <div className="w-96 bg-white border-l border-gray-200 flex flex-col shadow-soft-lg">
          <div className="p-4 border-b border-gray-200 bg-gradient-to-r from-[#003A70] to-[#005EB8]">
            <h3 className="text-white text-sm">BOQ Detail</h3>
            <p className="text-xs text-blue-100 mt-1">{selectedBOQ}</p>
          </div>

          <div className="flex-1 overflow-auto p-4">
            <div className="space-y-4">
              {/* Material Breakdown */}
              <div className="glass-card rounded-lg p-4">
                <h4 className="text-xs text-gray-600 mb-3">Material Breakdown</h4>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-700">Material Cost</span>
                    <span className="text-gray-900">Rp 120,000,000</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-700">Labor Cost</span>
                    <span className="text-gray-900">Rp 45,000,000</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-700">Equipment</span>
                    <span className="text-gray-900">Rp 22,500,000</span>
                  </div>
                  <div className="border-t border-gray-200 pt-2 mt-2 flex justify-between">
                    <span className="text-sm text-gray-900">Total</span>
                    <span className="text-sm text-gray-900">Rp 187,500,000</span>
                  </div>
                </div>
              </div>

              {/* Evidence Tagging */}
              <div className="glass-card rounded-lg p-4">
                <h4 className="text-xs text-gray-600 mb-3">Evidence Tagged</h4>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                    <Paperclip className="w-4 h-4 text-gray-600" />
                    <div className="flex-1">
                      <div className="text-xs text-gray-900">survey_report.pdf</div>
                      <div className="text-xs text-gray-500">2.4 MB</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                    <Paperclip className="w-4 h-4 text-gray-600" />
                    <div className="flex-1">
                      <div className="text-xs text-gray-900">material_spec.xlsx</div>
                      <div className="text-xs text-gray-500">856 KB</div>
                    </div>
                  </div>
                </div>
                <button className="w-full mt-2 px-3 py-2 border border-dashed border-gray-300 rounded text-xs text-gray-600 hover:bg-gray-50">
                  + Add Evidence
                </button>
              </div>

              {/* KML Location */}
              <div className="glass-card rounded-lg p-4">
                <h4 className="text-xs text-gray-600 mb-3">KML Location</h4>
                <div className="w-full h-32 bg-gray-200 rounded flex items-center justify-center mb-3">
                  <MapPin className="w-8 h-8 text-gray-400" />
                </div>
                <button className="w-full px-3 py-2 bg-[#005EB8] text-white rounded text-xs hover:bg-[#004a94]">
                  View on Map
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
