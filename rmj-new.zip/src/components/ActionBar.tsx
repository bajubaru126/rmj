import { Save, ChevronDown, MoreHorizontal, History, Plus } from 'lucide-react';

interface ActionBarProps {
  selectedCount: number;
  onAttributeBuilder: () => void;
}

export function ActionBar({ selectedCount, onAttributeBuilder }: ActionBarProps) {
  return (
    <div className="bg-white border-b border-[#D1D5DB] px-6 py-3 flex items-center justify-between">
      {/* Left Actions */}
      <div className="flex items-center gap-3">
        <button className="flex items-center gap-2 px-4 py-2 bg-[#005EB8] text-white rounded hover:bg-[#004a94] transition-colors">
          <Save className="w-4 h-4" />
          Save
        </button>

        <div className="relative">
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded hover:bg-gray-50 transition-colors">
            Batch Actions
            <ChevronDown className="w-4 h-4" />
          </button>
          {selectedCount > 0 && (
            <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
              {selectedCount}
            </span>
          )}
        </div>

        <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded hover:bg-gray-50 transition-colors">
          More Actions
          <ChevronDown className="w-4 h-4" />
        </button>

        <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded hover:bg-gray-50 transition-colors">
          <History className="w-4 h-4" />
          Editing History
        </button>

        <button 
          onClick={onAttributeBuilder}
          className="flex items-center gap-2 px-4 py-2 border border-[#005EB8] text-[#005EB8] rounded hover:bg-blue-50 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add Attribute
        </button>
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-3">
        <select className="px-3 py-2 border border-gray-300 rounded text-sm">
          <option>10 per page</option>
          <option>25 per page</option>
          <option>50 per page</option>
          <option>100 per page</option>
        </select>

        <div className="flex items-center gap-2 text-sm text-gray-600">
          <button className="px-3 py-1.5 border border-gray-300 rounded hover:bg-gray-50">
            {'<'}
          </button>
          <span>Page 1 of 45</span>
          <button className="px-3 py-1.5 border border-gray-300 rounded hover:bg-gray-50">
            {'>'}
          </button>
        </div>

        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" className="rounded" />
          <span>Issue Mode</span>
        </label>
      </div>
    </div>
  );
}
