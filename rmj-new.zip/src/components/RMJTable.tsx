import { useState } from 'react';
import { ChevronRight, ChevronDown, Paperclip, AlertCircle, Edit, Trash2, Eye } from 'lucide-react';

interface RMJTableProps {
  selectedRows: string[];
  onSelectionChange: (rows: string[]) => void;
}

interface RowData {
  id: string;
  level: number;
  kontrak: string;
  treg: string;
  paketArea: string;
  lokasi?: string;
  ruasKontrak?: string;
  segmentasi?: string;
  cell?: string;
  currentMilestone?: string;
  planRFS?: string;
  actualEnd?: string;
  owner?: string;
  evidenceCount?: number;
  issueCount?: number;
  hasChildren?: boolean;
  children?: RowData[];
}

const mockData: RowData[] = [
  {
    id: 'k1',
    level: 0,
    kontrak: 'RMJ-2024-001',
    treg: 'TREG-1',
    paketArea: 'Paket 1',
    currentMilestone: 'Design',
    planRFS: '2024-06-30',
    owner: 'PT Meindo',
    evidenceCount: 15,
    issueCount: 3,
    hasChildren: true,
    children: [
      {
        id: 'k1-l1',
        level: 1,
        kontrak: 'RMJ-2024-001',
        treg: 'TREG-1',
        paketArea: 'Paket 1',
        lokasi: 'Jakarta Pusat',
        currentMilestone: 'Survey',
        planRFS: '2024-05-15',
        owner: 'Team A',
        evidenceCount: 8,
        issueCount: 1,
        hasChildren: true,
        children: [
          {
            id: 'k1-l1-r1',
            level: 2,
            kontrak: 'RMJ-2024-001',
            treg: 'TREG-1',
            paketArea: 'Paket 1',
            lokasi: 'Jakarta Pusat',
            ruasKontrak: 'SS-JKT-001',
            currentMilestone: 'Implementation',
            planRFS: '2024-05-20',
            actualEnd: '2024-05-18',
            owner: 'Vendor XYZ',
            evidenceCount: 12,
            issueCount: 0,
            hasChildren: true,
          }
        ]
      }
    ]
  },
  {
    id: 'k2',
    level: 0,
    kontrak: 'RMJ-2024-002',
    treg: 'TREG-2',
    paketArea: 'Paket 2',
    currentMilestone: 'Planning',
    planRFS: '2024-07-15',
    owner: 'PT Sumatera',
    evidenceCount: 5,
    issueCount: 2,
    hasChildren: false,
  }
];

export function RMJTable({ selectedRows, onSelectionChange }: RMJTableProps) {
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set(['k1']));
  const [expandedSubTabs, setExpandedSubTabs] = useState<Set<string>>(new Set());
  const [activeSubTab, setActiveSubTab] = useState<{ [key: string]: string }>({});

  const toggleRow = (rowId: string) => {
    const newExpanded = new Set(expandedRows);
    if (newExpanded.has(rowId)) {
      newExpanded.delete(rowId);
    } else {
      newExpanded.add(rowId);
    }
    setExpandedRows(newExpanded);
  };

  const toggleSubTabs = (rowId: string) => {
    const newExpanded = new Set(expandedSubTabs);
    if (newExpanded.has(rowId)) {
      newExpanded.delete(rowId);
    } else {
      newExpanded.add(rowId);
      if (!activeSubTab[rowId]) {
        setActiveSubTab({ ...activeSubTab, [rowId]: 'drm' });
      }
    }
    setExpandedSubTabs(newExpanded);
  };

  const handleSelectRow = (rowId: string) => {
    const newSelected = selectedRows.includes(rowId)
      ? selectedRows.filter(id => id !== rowId)
      : [...selectedRows, rowId];
    onSelectionChange(newSelected);
  };

  const handleSelectAll = () => {
    // Implementation for select all
    onSelectionChange([]);
  };

  const getStatusColor = (status?: string) => {
    switch (status) {
      case 'Implementation':
      case 'Done':
        return 'bg-[#4CAF50] text-white';
      case 'Design':
      case 'Survey':
      case 'Planning':
        return 'bg-[#FFC107] text-gray-900';
      case 'Issue':
        return 'bg-[#FF5252] text-white';
      default:
        return 'bg-gray-200 text-gray-700';
    }
  };

  const renderSubTabs = (rowId: string) => {
    const currentTab = activeSubTab[rowId] || 'drm';

    return (
      <tr>
        <td colSpan={14} className="bg-[#F8FAFC] p-0">
          {/* Sub Tab Navigation */}
          <div className="flex border-b border-[#D1D5DB] px-6">
            {['drm', 'boq', 'iboq', 'segmentasi', 'issue', 'evidence'].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveSubTab({ ...activeSubTab, [rowId]: tab })}
                className={`px-4 py-2 text-sm border-b-2 transition-colors ${
                  currentTab === tab
                    ? 'border-[#005EB8] text-[#005EB8]'
                    : 'border-transparent text-gray-600 hover:text-gray-900'
                }`}
              >
                {tab === 'drm' && 'DRM Data'}
                {tab === 'boq' && 'BOQ Customer'}
                {tab === 'iboq' && 'Indikatif BOQ'}
                {tab === 'segmentasi' && 'Segmentasi'}
                {tab === 'issue' && 'Issue Log'}
                {tab === 'evidence' && 'Evidence'}
              </button>
            ))}
          </div>

          {/* Sub Tab Content */}
          <div className="p-6">
            {currentTab === 'drm' && (
              <table className="w-full text-sm">
                <thead className="bg-[#E9ECEF]">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs">No Ruas</th>
                    <th className="px-4 py-2 text-left text-xs">Nama Ruas</th>
                    <th className="px-4 py-2 text-left text-xs">Panjang KM</th>
                    <th className="px-4 py-2 text-left text-xs">Evidence</th>
                    <th className="px-4 py-2 text-left text-xs">Updated By</th>
                    <th className="px-4 py-2 text-left text-xs">Updated At</th>
                  </tr>
                </thead>
                <tbody className="bg-white">
                  <tr className="border-b border-gray-200">
                    <td className="px-4 py-3">DRM-001</td>
                    <td className="px-4 py-3">Ruas Jakarta-Bandung</td>
                    <td className="px-4 py-3">45.5 km</td>
                    <td className="px-4 py-3">
                      <button className="flex items-center gap-1 text-blue-600 hover:underline">
                        <Paperclip className="w-3 h-3" />
                        5 files
                      </button>
                    </td>
                    <td className="px-4 py-3">Hendra P.</td>
                    <td className="px-4 py-3">2024-03-15 14:30</td>
                  </tr>
                </tbody>
              </table>
            )}

            {currentTab === 'boq' && (
              <table className="w-full text-sm">
                <thead className="bg-[#E9ECEF]">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs">BOQID</th>
                    <th className="px-4 py-2 text-left text-xs">Kategori</th>
                    <th className="px-4 py-2 text-left text-xs">Designator</th>
                    <th className="px-4 py-2 text-left text-xs">Uraian</th>
                    <th className="px-4 py-2 text-left text-xs">Qty</th>
                    <th className="px-4 py-2 text-left text-xs">Satuan</th>
                    <th className="px-4 py-2 text-left text-xs">Harga</th>
                    <th className="px-4 py-2 text-left text-xs">Total</th>
                  </tr>
                </thead>
                <tbody className="bg-white">
                  <tr className="border-b border-gray-200">
                    <td className="px-4 py-3">BOQ-001</td>
                    <td className="px-4 py-3">A. Kabel</td>
                    <td className="px-4 py-3">KB-48F</td>
                    <td className="px-4 py-3">Kabel Fiber Optik 48 Core</td>
                    <td className="px-4 py-3">1500</td>
                    <td className="px-4 py-3">meter</td>
                    <td className="px-4 py-3">Rp 125,000</td>
                    <td className="px-4 py-3">Rp 187,500,000</td>
                  </tr>
                </tbody>
              </table>
            )}

            {currentTab === 'segmentasi' && (
              <div className="space-y-2">
                <div className="border border-gray-200 rounded p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm">SEG-A (2.5 km)</span>
                    <ChevronDown className="w-4 h-4" />
                  </div>
                  <div className="ml-4 space-y-1 text-sm text-gray-600">
                    <div>Cell 01 - 500m - Status: OK</div>
                    <div>Cell 02 - 500m - Status: OK</div>
                    <div>Cell 03 - 500m - Status: Progress</div>
                    <div>Cell 04 - 500m - Status: OK</div>
                    <div>Cell 05 - 500m - Status: OK</div>
                  </div>
                </div>
              </div>
            )}

            {currentTab === 'issue' && (
              <div className="space-y-2">
                <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded">
                  <AlertCircle className="w-4 h-4 text-red-600" />
                  <div className="flex-1">
                    <div className="text-sm text-red-900">Route change required due to permit issue</div>
                    <div className="text-xs text-red-600">Reported by: Faisal A. - 2024-03-10</div>
                  </div>
                </div>
              </div>
            )}

            {currentTab === 'evidence' && (
              <div className="grid grid-cols-4 gap-4">
                <div className="border border-gray-200 rounded p-3 text-center">
                  <div className="w-full h-32 bg-gray-100 rounded mb-2 flex items-center justify-center">
                    <Paperclip className="w-8 h-8 text-gray-400" />
                  </div>
                  <div className="text-xs text-gray-600">survey_report.pdf</div>
                  <div className="text-xs text-gray-400">2.4 MB</div>
                </div>
              </div>
            )}
          </div>
        </td>
      </tr>
    );
  };

  const renderRow = (row: RowData, depth: number = 0) => {
    const isExpanded = expandedRows.has(row.id);
    const isSelected = selectedRows.includes(row.id);
    const showSubTabs = expandedSubTabs.has(row.id);

    return (
      <>
        <tr 
          key={row.id}
          className={`border-b border-[#D1D5DB] hover:bg-gray-50 transition-colors ${
            isSelected ? 'bg-blue-50' : depth % 2 === 0 ? 'bg-white' : 'bg-[#F8FAFC]'
          }`}
        >
          {/* Checkbox */}
          <td className="px-4 py-3 w-12">
            <input
              type="checkbox"
              checked={isSelected}
              onChange={() => handleSelectRow(row.id)}
              className="rounded"
            />
          </td>

          {/* No Kontrak */}
          <td className="px-4 py-3">
            <div className="flex items-center gap-2" style={{ paddingLeft: `${depth * 20}px` }}>
              {row.hasChildren && (
                <button onClick={() => toggleRow(row.id)} className="hover:bg-gray-200 rounded p-0.5">
                  {isExpanded ? (
                    <ChevronDown className="w-4 h-4" />
                  ) : (
                    <ChevronRight className="w-4 h-4" />
                  )}
                </button>
              )}
              <span className="text-sm text-blue-600 hover:underline cursor-pointer">{row.kontrak}</span>
            </div>
          </td>

          {/* TREG */}
          <td className="px-4 py-3">
            <span className="text-sm">{row.treg}</span>
          </td>

          {/* Paket Area */}
          <td className="px-4 py-3">
            <span className="text-sm">{row.paketArea}</span>
          </td>

          {/* Lokasi */}
          <td className="px-4 py-3">
            <span className="text-sm">{row.lokasi || '-'}</span>
          </td>

          {/* Ruas Kontrak */}
          <td className="px-4 py-3">
            {row.ruasKontrak && (
              <button
                onClick={() => toggleSubTabs(row.id)}
                className="text-sm text-blue-600 hover:underline flex items-center gap-1"
              >
                {row.ruasKontrak}
                {showSubTabs ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
              </button>
            )}
            {!row.ruasKontrak && <span className="text-sm text-gray-400">-</span>}
          </td>

          {/* Segmentasi */}
          <td className="px-4 py-3">
            <span className="text-sm">{row.segmentasi || '-'}</span>
          </td>

          {/* Cell */}
          <td className="px-4 py-3">
            <span className="text-sm">{row.cell || '-'}</span>
          </td>

          {/* Current Milestone */}
          <td className="px-4 py-3">
            {row.currentMilestone && (
              <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(row.currentMilestone)}`}>
                {row.currentMilestone}
              </span>
            )}
          </td>

          {/* Plan RFS Date */}
          <td className="px-4 py-3">
            <span className="text-sm">{row.planRFS || '-'}</span>
          </td>

          {/* Actual End Date */}
          <td className="px-4 py-3">
            <span className="text-sm">{row.actualEnd || '-'}</span>
          </td>

          {/* Owner */}
          <td className="px-4 py-3">
            <span className="text-sm">{row.owner}</span>
          </td>

          {/* Evidence */}
          <td className="px-4 py-3 text-center">
            {(row.evidenceCount ?? 0) > 0 && (
              <button className="flex items-center gap-1 text-blue-600 hover:underline text-sm">
                <Paperclip className="w-3 h-3" />
                {row.evidenceCount}
              </button>
            )}
          </td>

          {/* Issues */}
          <td className="px-4 py-3 text-center">
            {(row.issueCount ?? 0) > 0 && (
              <button className="flex items-center gap-1 text-red-600 hover:underline text-sm">
                <AlertCircle className="w-3 h-3" />
                {row.issueCount}
              </button>
            )}
          </td>

          {/* Action */}
          <td className="px-4 py-3">
            <div className="flex items-center gap-1">
              <button className="p-1 hover:bg-gray-200 rounded" title="View">
                <Eye className="w-4 h-4 text-gray-600" />
              </button>
              <button className="p-1 hover:bg-gray-200 rounded" title="Edit">
                <Edit className="w-4 h-4 text-blue-600" />
              </button>
              <button className="p-1 hover:bg-gray-200 rounded" title="Delete">
                <Trash2 className="w-4 h-4 text-red-600" />
              </button>
            </div>
          </td>
        </tr>

        {/* Sub Tabs */}
        {showSubTabs && renderSubTabs(row.id)}

        {/* Children Rows */}
        {isExpanded && row.children?.map(child => renderRow(child, depth + 1))}
      </>
    );
  };

  return (
    <div className="bg-white">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-[#E9ECEF] border-b border-[#D1D5DB] sticky top-0">
            <tr>
              <th className="px-4 py-3 w-12">
                <input type="checkbox" onChange={handleSelectAll} className="rounded" />
              </th>
              <th className="px-4 py-3 text-left text-xs text-gray-700 min-w-[150px]">No Kontrak</th>
              <th className="px-4 py-3 text-left text-xs text-gray-700 w-24">TREG</th>
              <th className="px-4 py-3 text-left text-xs text-gray-700 w-32">Paket Area</th>
              <th className="px-4 py-3 text-left text-xs text-gray-700 min-w-[150px]">Lokasi / Witel</th>
              <th className="px-4 py-3 text-left text-xs text-gray-700 min-w-[150px]">Ruas Kontrak</th>
              <th className="px-4 py-3 text-left text-xs text-gray-700 w-32">Segmentasi</th>
              <th className="px-4 py-3 text-left text-xs text-gray-700 w-24">Cell</th>
              <th className="px-4 py-3 text-left text-xs text-gray-700 w-40">Current Milestone</th>
              <th className="px-4 py-3 text-left text-xs text-gray-700 w-32">Plan RFS Date</th>
              <th className="px-4 py-3 text-left text-xs text-gray-700 w-32">Actual End Date</th>
              <th className="px-4 py-3 text-left text-xs text-gray-700 min-w-[150px]">Owner</th>
              <th className="px-4 py-3 text-center text-xs text-gray-700 w-24">Evidence</th>
              <th className="px-4 py-3 text-center text-xs text-gray-700 w-24">Issues</th>
              <th className="px-4 py-3 text-center text-xs text-gray-700 w-32">Action</th>
            </tr>
          </thead>
          <tbody>
            {mockData.map(row => renderRow(row))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
