import { LayoutDashboard, FolderTree, Route, Package, Grid3x3, AlertCircle, Wrench, Download } from 'lucide-react';

interface TabNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const tabs = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'kontrak', label: 'Kontrak Explorer', icon: FolderTree },
  { id: 'ruas', label: 'Ruas & DRM', icon: Route },
  { id: 'boq', label: 'BOQ Manager', icon: Package },
  { id: 'segmentasi', label: 'Segmentasi & Cell', icon: Grid3x3 },
  { id: 'issue', label: 'Issue Center', icon: AlertCircle },
  { id: 'attribute', label: 'Attribute Builder', icon: Wrench },
  { id: 'import', label: 'Import / Export', icon: Download },
];

export function TabNavigation({ activeTab, onTabChange }: TabNavigationProps) {
  return (
    <div className="bg-white border-b border-[#D1D5DB]" style={{ height: '48px' }}>
      <div className="flex items-center h-full px-6">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex items-center gap-2 px-4 h-full border-b-2 transition-colors ${
                isActive
                  ? 'border-[#005EB8] text-[#005EB8]'
                  : 'border-transparent text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-sm">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
