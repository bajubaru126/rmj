import { Bell, User, ChevronDown } from 'lucide-react';

export function Header() {
  return (
    <div className="bg-[#003A70] text-white px-6 py-3 flex items-center justify-between" style={{ height: '60px' }}>
      {/* Left: Logo & Title */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
            <span className="text-xl">📊</span>
          </div>
          <div>
            <h1 className="text-lg">SmartRMJ</h1>
          </div>
        </div>
      </div>

      {/* Right: User Info & Actions */}
      <div className="flex items-center gap-4">
        {/* User Role Indicator */}
        <div className="text-sm px-3 py-1.5 bg-white/10 rounded">
          IT Developer - AAA
        </div>

        {/* Notification */}
        <button className="relative p-2 hover:bg-white/10 rounded-lg transition-colors">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
        </button>

        {/* User Avatar Dropdown */}
        <button className="flex items-center gap-2 px-3 py-1.5 hover:bg-white/10 rounded-lg transition-colors">
          <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
            <User className="w-5 h-5" />
          </div>
          <span className="text-sm">Faisal Ahmad</span>
          <ChevronDown className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}