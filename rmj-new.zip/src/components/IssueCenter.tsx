import { AlertCircle, Search, Filter, X, Plus, ChevronRight } from 'lucide-react';
import { useState } from 'react';

interface IssueCenterProps {
  onClose: () => void;
}

interface Issue {
  id: string;
  type: string;
  description: string;
  ruas: string;
  segmentasi?: string;
  status: string;
  updatedBy: string;
  date: string;
  priority: string;
}

const mockIssues: Issue[] = [
  {
    id: 'ISS-001',
    type: 'Route Change',
    description: 'Permit issue at KM 12.5 - need alternative route',
    ruas: 'SS-JKT-001',
    segmentasi: 'SEG-A',
    status: 'Open',
    updatedBy: 'Faisal Ahmad',
    date: '2024-03-15',
    priority: 'High',
  },
  {
    id: 'ISS-002',
    type: 'Material Delay',
    description: 'Fiber optic cable delivery delayed by 2 weeks',
    ruas: 'SS-JKT-002',
    status: 'In Progress',
    updatedBy: 'Hendra Pratama',
    date: '2024-03-14',
    priority: 'Medium',
  },
  {
    id: 'ISS-003',
    type: 'Quality Issue',
    description: 'Splice loss exceeds standard at Cell 05',
    ruas: 'SS-BDG-001',
    segmentasi: 'SEG-B',
    status: 'Resolved',
    updatedBy: 'Subhan Rahman',
    date: '2024-03-10',
    priority: 'Low',
  },
];

export function IssueCenter({ onClose }: IssueCenterProps) {
  const [selectedIssue, setSelectedIssue] = useState<Issue | null>(mockIssues[0]);
  const [filterStatus, setFilterStatus] = useState('all');

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High': return 'bg-[#FF5252] text-white';
      case 'Medium': return 'bg-[#FFC107] text-gray-900';
      case 'Low': return 'bg-[#4CAF50] text-white';
      default: return 'bg-gray-200 text-gray-700';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Open': return 'bg-red-100 text-red-700';
      case 'In Progress': return 'bg-yellow-100 text-yellow-700';
      case 'Resolved': return 'bg-green-100 text-green-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="flex h-full bg-white">
      {/* Left Panel - Filters */}
      <div className="w-64 border-r border-[#D1D5DB] p-4 bg-[#F8F8F8]">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm text-gray-700">Filters</h3>
          <button className="text-xs text-blue-600 hover:underline">Clear</button>
        </div>

        <div className="space-y-4">
          {/* Status Filter */}
          <div>
            <label className="block text-xs text-gray-600 mb-2">Status</label>
            <select 
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-gray-300 rounded text-sm"
            >
              <option value="all">All Status</option>
              <option value="open">Open</option>
              <option value="progress">In Progress</option>
              <option value="resolved">Resolved</option>
            </select>
          </div>

          {/* Priority Filter */}
          <div>
            <label className="block text-xs text-gray-600 mb-2">Priority</label>
            <div className="space-y-2">
              <label className="flex items-center gap-2">
                <input type="checkbox" className="rounded" defaultChecked />
                <span className="text-sm">High</span>
              </label>
              <label className="flex items-center gap-2">
                <input type="checkbox" className="rounded" defaultChecked />
                <span className="text-sm">Medium</span>
              </label>
              <label className="flex items-center gap-2">
                <input type="checkbox" className="rounded" defaultChecked />
                <span className="text-sm">Low</span>
              </label>
            </div>
          </div>

          {/* Type Filter */}
          <div>
            <label className="block text-xs text-gray-600 mb-2">Issue Type</label>
            <select className="w-full px-3 py-2 bg-white border border-gray-300 rounded text-sm">
              <option>All Types</option>
              <option>Route Change</option>
              <option>Material Delay</option>
              <option>Quality Issue</option>
              <option>Permit Issue</option>
            </select>
          </div>

          {/* Date Range */}
          <div>
            <label className="block text-xs text-gray-600 mb-2">Date Range</label>
            <input type="date" className="w-full px-3 py-2 bg-white border border-gray-300 rounded text-sm mb-2" />
            <input type="date" className="w-full px-3 py-2 bg-white border border-gray-300 rounded text-sm" />
          </div>
        </div>
      </div>

      {/* Center Panel - Issue List */}
      <div className="flex-1 flex flex-col">
        {/* Search Bar */}
        <div className="p-4 border-b border-[#D1D5DB]">
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search issues..."
                className="w-full pl-9 pr-4 py-2 border border-gray-300 rounded"
              />
            </div>
            <button className="flex items-center gap-2 px-4 py-2 bg-[#005EB8] text-white rounded hover:bg-[#004a94]">
              <Plus className="w-4 h-4" />
              New Issue
            </button>
          </div>
        </div>

        {/* Issue Table */}
        <div className="flex-1 overflow-auto">
          <table className="w-full">
            <thead className="bg-[#E9ECEF] border-b border-[#D1D5DB] sticky top-0">
              <tr>
                <th className="px-4 py-3 text-left text-xs text-gray-700">Issue Type</th>
                <th className="px-4 py-3 text-left text-xs text-gray-700">Description</th>
                <th className="px-4 py-3 text-left text-xs text-gray-700">Ruas</th>
                <th className="px-4 py-3 text-left text-xs text-gray-700">Segmentasi</th>
                <th className="px-4 py-3 text-left text-xs text-gray-700">Priority</th>
                <th className="px-4 py-3 text-left text-xs text-gray-700">Status</th>
                <th className="px-4 py-3 text-left text-xs text-gray-700">Updated By</th>
                <th className="px-4 py-3 text-left text-xs text-gray-700">Date</th>
              </tr>
            </thead>
            <tbody>
              {mockIssues.map((issue) => (
                <tr
                  key={issue.id}
                  onClick={() => setSelectedIssue(issue)}
                  className={`border-b border-gray-200 cursor-pointer hover:bg-gray-50 ${
                    selectedIssue?.id === issue.id ? 'bg-blue-50' : ''
                  }`}
                >
                  <td className="px-4 py-3 text-sm">{issue.type}</td>
                  <td className="px-4 py-3 text-sm">{issue.description}</td>
                  <td className="px-4 py-3 text-sm">{issue.ruas}</td>
                  <td className="px-4 py-3 text-sm">{issue.segmentasi || '-'}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 rounded-full text-xs ${getPriorityColor(issue.priority)}`}>
                      {issue.priority}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(issue.status)}`}>
                      {issue.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm">{issue.updatedBy}</td>
                  <td className="px-4 py-3 text-sm">{issue.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Right Panel - Issue Details */}
      {selectedIssue && (
        <div className="w-96 border-l border-[#D1D5DB] flex flex-col">
          {/* Header */}
          <div className="p-4 border-b border-[#D1D5DB] bg-[#F8F8F8]">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm">Issue Details</h3>
              <button onClick={() => setSelectedIssue(null)} className="p-1 hover:bg-gray-200 rounded">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="text-xs text-gray-500">{selectedIssue.id}</div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-auto p-4">
            <div className="space-y-4">
              {/* Type & Priority */}
              <div className="flex items-center gap-2">
                <span className={`px-3 py-1 rounded-full text-xs ${getPriorityColor(selectedIssue.priority)}`}>
                  {selectedIssue.priority}
                </span>
                <span className={`px-3 py-1 rounded-full text-xs ${getStatusColor(selectedIssue.status)}`}>
                  {selectedIssue.status}
                </span>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs text-gray-600 mb-1">Description</label>
                <p className="text-sm text-gray-900">{selectedIssue.description}</p>
              </div>

              {/* Location */}
              <div>
                <label className="block text-xs text-gray-600 mb-1">Location</label>
                <div className="text-sm text-gray-900">
                  <div>Ruas: {selectedIssue.ruas}</div>
                  {selectedIssue.segmentasi && <div>Segmentasi: {selectedIssue.segmentasi}</div>}
                </div>
              </div>

              {/* Timeline */}
              <div>
                <label className="block text-xs text-gray-600 mb-2">Activity Timeline</label>
                <div className="space-y-3">
                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <AlertCircle className="w-4 h-4 text-blue-600" />
                    </div>
                    <div>
                      <div className="text-sm text-gray-900">Issue reported</div>
                      <div className="text-xs text-gray-500">{selectedIssue.updatedBy} • {selectedIssue.date}</div>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <ChevronRight className="w-4 h-4 text-yellow-600" />
                    </div>
                    <div>
                      <div className="text-sm text-gray-900">Assigned to team</div>
                      <div className="text-xs text-gray-500">System • 2024-03-15 10:30</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Comments */}
              <div>
                <label className="block text-xs text-gray-600 mb-2">Comments</label>
                <div className="space-y-2">
                  <div className="p-3 bg-gray-50 rounded border border-gray-200">
                    <div className="text-sm text-gray-900 mb-1">Investigating the route alternatives</div>
                    <div className="text-xs text-gray-500">Faisal Ahmad • 2 hours ago</div>
                  </div>
                </div>
                <textarea
                  placeholder="Add a comment..."
                  rows={3}
                  className="w-full mt-2 px-3 py-2 border border-gray-300 rounded text-sm"
                />
                <button className="mt-2 w-full px-4 py-2 bg-[#005EB8] text-white rounded hover:bg-[#004a94] text-sm">
                  Add Comment
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
