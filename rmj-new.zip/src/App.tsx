import { useState } from 'react';
import { Header } from './components/Header';
import { TabNavigation } from './components/TabNavigation';
import { FilterBar } from './components/FilterBar';
import { ActionBar } from './components/ActionBar';
import { Dashboard } from './components/Dashboard';
import { KontrakExplorer } from './components/KontrakExplorer';
import { RuasDRM } from './components/RuasDRM';
import { BOQManager } from './components/BOQManager';
import { RMJTable } from './components/RMJTable';
import { AttributeBuilder } from './components/AttributeBuilder';
import { IssueCenter } from './components/IssueCenter';
import { ImportExport } from './components/ImportExport';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showAttributeBuilder, setShowAttributeBuilder] = useState(false);
  const [showImportExport, setShowImportExport] = useState(false);
  const [selectedRows, setSelectedRows] = useState<string[]>([]);

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    if (tab === 'attribute') {
      setShowAttributeBuilder(true);
    } else if (tab === 'import') {
      setShowImportExport(true);
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'kontrak':
        return <KontrakExplorer />;
      case 'ruas':
        return <RuasDRM />;
      case 'boq':
        return <BOQManager />;
      case 'segmentasi':
        return <RuasDRM />;
      case 'issue':
        return <IssueCenter onClose={() => setActiveTab('dashboard')} />;
      default:
        return (
          <div className="flex-1 flex flex-col overflow-hidden">
            <FilterBar />
            <ActionBar 
              selectedCount={selectedRows.length}
              onAttributeBuilder={() => setShowAttributeBuilder(true)}
            />
            <div className="flex-1 overflow-auto">
              <RMJTable 
                selectedRows={selectedRows}
                onSelectionChange={setSelectedRows}
              />
            </div>
          </div>
        );
    }
  };

  return (
    <div className="flex h-screen bg-[#F5F5F5] overflow-hidden">
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <Header />

        {/* Tab Navigation */}
        <TabNavigation activeTab={activeTab} onTabChange={handleTabChange} />

        {/* Main Content Area */}
        <div className="flex-1 flex overflow-hidden">
          {/* Main Content */}
          <div className="flex-1 overflow-hidden">
            {renderContent()}
          </div>

          {/* Attribute Builder Slide-out */}
          {showAttributeBuilder && (
            <AttributeBuilder onClose={() => setShowAttributeBuilder(false)} />
          )}
        </div>

        {/* Import/Export Modal */}
        {showImportExport && (
          <ImportExport onClose={() => setShowImportExport(false)} />
        )}
      </div>
    </div>
  );
}